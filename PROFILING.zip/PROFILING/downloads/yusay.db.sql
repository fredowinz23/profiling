﻿# Host: localhost  (Version 5.5.5-10.1.34-MariaDB)
# Date: 2023-11-22 18:21:26
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "account"
#

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `Id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Inactive',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `volunteerId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

#
# Data for table "account"
#

INSERT INTO `account` VALUES (1,'admin','1234','fre','Garcia','Active','Admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'chloe','123','Chloie','Silava','Active','Staff',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'vol','qq','test','vol','Active','Volunteer',NULL,NULL,NULL,NULL,NULL,NULL,2);

#
# Structure for table "beneficiary"
#

DROP TABLE IF EXISTS `beneficiary`;
CREATE TABLE `beneficiary` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `age` int(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `contactNumber` varchar(255) DEFAULT NULL,
  `address` text,
  `barangay` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `content` text,
  `status` varchar(255) DEFAULT 'Pending',
  `proof` varchar(255) DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

#
# Data for table "beneficiary"
#

INSERT INTO `beneficiary` VALUES (1,'First Name','Last Name','example_email@gmail.com',18,'Male','2121896','Taloc Proper South, Bago City, Negros Occ.','Taloc','Bago City','example content','Approved','','2023-11-11'),(2,'Chloie','Silava','silava@gmail.com',18,'Female','880808','Mansiligan','Mansiligan','Bacolod City','example content2','Pending','','2023-11-11'),(3,'Taylor','Swift','sgv@gmail.com',33,'Female','09543276891','Malibu','n/a','california','','Pending','1700048949391757614_708630397793995_6967883793607838672_n.jpg','2023-11-15');

#
# Structure for table "category"
#

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `isDeleted` int(11) DEFAULT '0',
  `description` text,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# Data for table "category"
#

INSERT INTO `category` VALUES (1,'Environmental Program',0,'programs under environmental program',NULL),(2,'Educational Program',0,'programs under educational program',NULL),(3,'Health Program',0,'programs under health program',NULL),(4,'Livelihood Program',0,'programs under livelihood program',NULL),(5,'Special Program',0,'programs under special program',NULL),(6,'Sports Program',0,'programs under sports program',NULL),(7,'Community Development Program',0,'programs involving uplifting community',NULL);

#
# Structure for table "donation"
#

DROP TABLE IF EXISTS `donation`;
CREATE TABLE `donation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `age` int(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `contactNumber` varchar(255) DEFAULT NULL,
  `address` text,
  `barangay` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `content` text,
  `status` varchar(255) DEFAULT 'Pending',
  `proof` varchar(255) DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `isAnonymous` varchar(255) DEFAULT 'Pending',
  `amount` double DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# Data for table "donation"
#

INSERT INTO `donation` VALUES (1,'Jerahmeel Hoshaiah','Francisco','s1920327@usls.edu.ph',18,'Male','10380184','Taloc Proper South, Bago City, Negros Occ.','Taloc','Bago City','Thank you note, donation','Approved','1699690159Giving of Sports Uniform.jpg','2023-11-11','No',100),(2,'Cherryl','Torbiso','cerryl@gmail.com',36,'Female','0915234567','blk 3 lot 3','purisima','manapla','KEEP ON HELPING','Pending','1699690159Giving of Sports Uniform.jpg','2023-11-11','No',20000),(3,'Stephen','Caballero','vhafnafja@gmail.com',23,'Male','0914000032','Montebello','Bata','Bacolod','','Pending',NULL,'2023-11-15','No',60000);

#
# Structure for table "joiner"
#

DROP TABLE IF EXISTS `joiner`;
CREATE TABLE `joiner` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `programId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "joiner"
#

INSERT INTO `joiner` VALUES (1,3,9),(3,1,9),(5,2,9),(6,4,9);

#
# Structure for table "program"
#

DROP TABLE IF EXISTS `program`;
CREATE TABLE `program` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `description` text,
  `categoryId` int(11) DEFAULT NULL,
  `address` text,
  `notes` text,
  `maxVolunteer` int(255) DEFAULT NULL,
  `amountSpent` double DEFAULT NULL,
  `status` varchar(255) DEFAULT 'Open',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# Data for table "program"
#

INSERT INTO `program` VALUES (1,'Singcang Tree Plantings','2023-11-18','12:30:00','test',1,'Singcang Airport','dsfdsf',10,20000,'Closed'),(2,'Kabugwason Clean Up Drive','2023-11-28','08:30:00','Clean Up DRIVE',1,'Kabugwason Mansilingan','',20,5000,'Approved'),(3,'Singcang Tree Planting','2023-11-18','12:30:00','Planting ',1,'Singcang Airport','',10,10000,'Closed'),(4,'KES School Supplies Giving','2023-12-01','11:00:00','Giving of School Supplies to KES students ',2,'KES mansilingan','',5,5000,'Approved'),(5,'School Shoes for a smile','2023-12-03','11:30:00','Giving out of school shoes for ABES 1 students',2,'ABES 1','',5,8000,'Pending'),(6,'Seniors Medical Checkup','2023-11-26','07:30:00','Medical Checkup for the elderly',3,'bago city gymnasium','',10,15000,'Pending'),(7,'Eye check you','2023-12-03','11:20:00','Free eye checking',3,'','',10,6000,'Pending'),(8,'Trash Can giving','2023-11-30','09:30:00','Giving of trash can',1,'Felisa','',5,5500,'Approved');

#
# Structure for table "volunteer"
#

DROP TABLE IF EXISTS `volunteer`;
CREATE TABLE `volunteer` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `mobileNumber` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ecName` varchar(255) DEFAULT NULL,
  `ecRelationship` varchar(255) DEFAULT NULL,
  `ecContactNumber` varchar(255) DEFAULT NULL,
  `elementary` varchar(255) DEFAULT NULL,
  `elementaryYear` varchar(255) DEFAULT NULL,
  `highschool` varchar(255) DEFAULT NULL,
  `highschoolYear` varchar(255) DEFAULT NULL,
  `college` varchar(255) DEFAULT NULL,
  `collegeYear` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `workFrom` varchar(255) DEFAULT NULL,
  `workTo` varchar(255) DEFAULT NULL,
  `dateAdded` varchar(255) DEFAULT NULL,
  `reason1` int(11) DEFAULT '0',
  `reason2` int(11) DEFAULT '0',
  `reason3` int(11) DEFAULT '0',
  `reason4` int(11) DEFAULT '0',
  `reason5` int(11) DEFAULT '0',
  `reason6` int(11) DEFAULT '0',
  `others` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'Pending',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "volunteer"
#

INSERT INTO `volunteer` VALUES (1,'kjhkjh','kjhkh','kjhkj','hkjh','kjhkj','98789','hkj','hkjh@sdsd.sdsd','87','98','7987','98798','798','798','798','798','98798','98798','798','798','798',NULL,1,0,1,0,1,0,'sdfds','Approved');
