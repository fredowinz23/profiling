<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";

?>


<p>
 <h3>Mission</h3>
  </p>
<p>
  To protect and promote the right of every Filipino to quality, equitable, cultured-based, and complete basic education where;

  </p>
  <p>
  Students learn in a child-friendly, gender-sensitive, safe, and motivating environment.
  Teachers facilitate learning and constantly nurture every learner.
  Administrators and Staff, as stewards of the institution, insure an enabling and supportive environment for effective learning to happen.
  Family, Community, and other stakeholders are actively engaged and share responsibility for developing life-long learners.

  </p>
  <p>
 <h3>Vision</h3>
  </p>
  <p>
  We, dreamed of Filipinos who passionately love their country and who’s values and competences and enable them to realize their full potential and contribute meaningfully to building the nation.

  </p>
  <p>
  As a learner-centered public institution, the Department of Education continuously improves itself to better serve it’s stakeholders.
</p>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
